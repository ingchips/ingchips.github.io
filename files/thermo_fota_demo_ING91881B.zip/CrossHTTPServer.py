import sys
import ssl

if sys.version_info[0] == 2:
    import BaseHTTPServer, SimpleHTTPServer
    from SimpleHTTPServer import SimpleHTTPRequestHandler
    from BaseHTTPServer import HTTPServer
elif sys.version_info[0] == 3:
    from http.server import HTTPServer, BaseHTTPRequestHandler, SimpleHTTPRequestHandler

class MyHTTPRequestHandler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_my_headers()
        SimpleHTTPRequestHandler.end_headers(self)
    def send_my_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")

httpd = HTTPServer(('192.168.100.102', 443), MyHTTPRequestHandler)

httpd.socket = ssl.wrap_socket (httpd.socket,
        keyfile="key.pem",
        certfile='cert.pem', server_side=True)

httpd.serve_forever()
